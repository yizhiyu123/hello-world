## 什么是job-demo?
***
job-demo 是一个简单定时任务demo，启动busybox容器sleep 30s后，任务结束，容器自动停止.