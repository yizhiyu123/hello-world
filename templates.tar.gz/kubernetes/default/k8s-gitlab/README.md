## 什么是gitlab?
***
GitLab是由GitLabInc.开发，使用MIT许可证的基于网络的Git仓库管理工具，且具有wiki和issue跟踪功能。使用Git作为代码管理工具，并在此基础上搭建起来的web服务。
## 注意事项
***
"your_node_ip" 是当前集群下的某一台主机的ip.