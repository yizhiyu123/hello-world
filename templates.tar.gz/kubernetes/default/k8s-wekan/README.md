## What is Wekan?
***
Wekan is an completely Open Source and Free software collaborative kanban board application with MIT license.

Whether you’re maintaining a personal todo list, planning your holidays with some friends, or working in a team on your next revolutionary idea, Kanban boards are an unbeatable tool to keep your things organized. They give you a visual overview of the current state of your project, and make you productive by allowing you to focus on the few items that matter the most.

Since Wekan is a free software, you don’t have to trust us with your data and can install Wekan on your own computer or server. In fact we encourage you to do that by providing one-click installation on various platforms.
